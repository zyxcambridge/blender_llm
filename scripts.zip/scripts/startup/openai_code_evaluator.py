# import os
# from openai import OpenAI

# # 写死 GITHUB_TOKEN
# os.environ["GITHUB_TOKEN"] = "<YOUR_GITHUB_TOKEN>"  # 已移除敏感信息，请通过环境变量安全设置
# token = os.environ["GITHUB_TOKEN"]
# endpoint = os.environ.get("OPENAI_API_BASE", "https://models.github.ai/inference")
# model = os.environ.get("OPENAI_MODEL", "openai/gpt-4.1")

# client = OpenAI(
#     base_url=endpoint,
#     api_key=token,
# )

# def evaluate_and_fix_code(code, error_message):
#     system_prompt = (
#         "你是一个Blender Python代码修复专家。请根据用户提供的错误信息和当前代码，给出如下格式的评估和修复建议：\n"
#         "1. 总体评估: [通过/不通过]\n"
#         "2. 问题列表: [如果有问题，列出每个问题]\n"
#         "3. 修复建议: [针对每个问题提供具体的修复代码]\n"
#         "4. 修复后的完整代码: [如果有修复建议，提供完整的修复后代码]\n"
#         "- 当前环境是Blender 4.5, 只允许4.5 API。\n"
#         "- 参考API文档: https://docs.blender.org/api/current/\n"
#         "- 只返回Python代码，不要包含解释或注释，代码可直接运行。"
#     )
#     user_prompt = f"错误信息：\n{error_message}\n当前代码：\n```python\n{code}\n```"
#     try:
#         response = client.chat.completions.create(
#             messages=[
#                 {"role": "system", "content": system_prompt},
#                 {"role": "user", "content": user_prompt}
#             ],
#             temperature=0.3,
#             top_p=1.0,
#             max_tokens=32768,
#             model=model
#         )
#         content = response.choices[0].message.content
#         return True, content
#     except Exception as e:
#         return False, f"OpenAI API 调用失败: {e}"

# if __name__ == "__main__":
#     import sys
#     if len(sys.argv) < 3:
#         print("用法: python openai_code_evaluator.py <code_file> <error_message_file>")
#         exit(1)
#     with open(sys.argv[1], 'r', encoding='utf-8') as f:
#         code = f.read()
#     with open(sys.argv[2], 'r', encoding='utf-8') as f:
#         error_message = f.read()
#     success, result = evaluate_and_fix_code(code, error_message)
#     if success:
#         print(result)
#     else:
#         print(f"评估失败: {result}")
