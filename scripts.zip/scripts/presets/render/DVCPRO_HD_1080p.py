import bpy
bpy.context.scene.render.resolution_x = 1280
bpy.context.scene.render.resolution_y = 1080
bpy.context.scene.render.resolution_percentage = 100
bpy.context.scene.render.pixel_aspect_x = 3
bpy.context.scene.render.pixel_aspect_y = 2
bpy.context.scene.render.fps = 24
bpy.context.scene.render.fps_base = 1
