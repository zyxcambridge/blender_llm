import bpy
bpy.context.scene.render.resolution_x = 720
bpy.context.scene.render.resolution_y = 486
bpy.context.scene.render.resolution_percentage = 100
bpy.context.scene.render.pixel_aspect_x = 10
bpy.context.scene.render.pixel_aspect_y = 11
bpy.context.scene.render.fps = 30
bpy.context.scene.render.fps_base = 1.001
