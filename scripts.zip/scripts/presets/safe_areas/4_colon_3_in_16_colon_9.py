import bpy
safe_areas = bpy.context.scene.safe_areas

safe_areas.title = (0.035, 0.035)
safe_areas.action = (0.1, 0.05)
safe_areas.title_center = (0.175, 0.05)
safe_areas.action_center = (0.15, 0.05)
