import bpy
bpy.context.camera.sensor_width = 6.17
bpy.context.camera.sensor_height = 4.55
bpy.context.camera.sensor_fit = 'HORIZONTAL'
