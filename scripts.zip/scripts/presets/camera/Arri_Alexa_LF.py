import bpy
bpy.context.camera.sensor_width = 36.70
bpy.context.camera.sensor_height = 25.54
bpy.context.camera.sensor_fit = 'HORIZONTAL'
