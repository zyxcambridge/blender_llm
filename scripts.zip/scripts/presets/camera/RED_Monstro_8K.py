import bpy
bpy.context.camera.sensor_width = 40.96
bpy.context.camera.sensor_height = 21.60
bpy.context.camera.sensor_fit = 'HORIZONTAL'
