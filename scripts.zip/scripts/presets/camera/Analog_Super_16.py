import bpy
bpy.context.camera.sensor_width = 12.35
bpy.context.camera.sensor_height = 7.42
bpy.context.camera.sensor_fit = 'HORIZONTAL'
