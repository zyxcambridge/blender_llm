import bpy
bpy.context.camera.sensor_width = 24.89
bpy.context.camera.sensor_height = 18.66
bpy.context.camera.sensor_fit = 'HORIZONTAL'
