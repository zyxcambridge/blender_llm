import bpy
bpy.context.camera.sensor_width = 7.18
bpy.context.camera.sensor_height = 5.32
bpy.context.camera.sensor_fit = 'HORIZONTAL'
