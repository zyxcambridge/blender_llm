import bpy
bpy.context.camera.sensor_width = 22.30
bpy.context.camera.sensor_height = 14.90
bpy.context.camera.sensor_fit = 'HORIZONTAL'
