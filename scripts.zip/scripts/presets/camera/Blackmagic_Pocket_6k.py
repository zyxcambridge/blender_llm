import bpy
bpy.context.camera.sensor_width = 23.10
bpy.context.camera.sensor_height = 12.99
bpy.context.camera.sensor_fit = 'HORIZONTAL'
