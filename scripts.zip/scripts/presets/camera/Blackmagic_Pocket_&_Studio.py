import bpy
bpy.context.camera.sensor_width = 12.48
bpy.context.camera.sensor_height = 7.02
bpy.context.camera.sensor_fit = 'HORIZONTAL'
