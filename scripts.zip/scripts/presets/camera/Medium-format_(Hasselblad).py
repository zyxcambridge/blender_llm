import bpy
bpy.context.camera.sensor_width = 44
bpy.context.camera.sensor_height = 33
bpy.context.camera.sensor_fit = 'HORIZONTAL'
