import bpy
bpy.context.camera.sensor_width = 8.8
bpy.context.camera.sensor_height = 6.6
bpy.context.camera.sensor_fit = 'HORIZONTAL'
