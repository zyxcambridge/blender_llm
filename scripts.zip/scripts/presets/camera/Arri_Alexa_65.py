import bpy
bpy.context.camera.sensor_width = 54.12
bpy.context.camera.sensor_height = 25.58
bpy.context.camera.sensor_fit = 'HORIZONTAL'
