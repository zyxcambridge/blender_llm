import bpy
bpy.context.camera.sensor_width = 71.41
bpy.context.camera.sensor_height = 52.63
bpy.context.camera.sensor_fit = 'HORIZONTAL'
