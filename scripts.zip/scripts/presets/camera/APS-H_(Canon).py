import bpy
bpy.context.camera.sensor_width = 27.90
bpy.context.camera.sensor_height = 18.60
bpy.context.camera.sensor_fit = 'HORIZONTAL'
