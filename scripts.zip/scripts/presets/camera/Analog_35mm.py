import bpy
bpy.context.camera.sensor_width = 22
bpy.context.camera.sensor_height = 16
bpy.context.camera.sensor_fit = 'HORIZONTAL'
