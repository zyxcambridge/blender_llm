import bpy
bpy.context.camera.sensor_width = 30.70
bpy.context.camera.sensor_height = 15.80
bpy.context.camera.sensor_fit = 'HORIZONTAL'
