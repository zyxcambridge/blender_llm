import bpy
bpy.context.camera.sensor_width = 20.70
bpy.context.camera.sensor_height = 13.80
bpy.context.camera.sensor_fit = 'HORIZONTAL'
