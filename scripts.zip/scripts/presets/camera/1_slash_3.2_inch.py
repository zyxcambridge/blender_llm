import bpy
bpy.context.camera.sensor_width = 4.54
bpy.context.camera.sensor_height = 3.42
bpy.context.camera.sensor_fit = 'HORIZONTAL'
