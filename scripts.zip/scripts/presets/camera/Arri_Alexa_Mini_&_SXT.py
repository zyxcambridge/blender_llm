import bpy
bpy.context.camera.sensor_width = 29.90
bpy.context.camera.sensor_height = 15.77
bpy.context.camera.sensor_fit = 'HORIZONTAL'
