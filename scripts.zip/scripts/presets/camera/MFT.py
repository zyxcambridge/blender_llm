import bpy
bpy.context.camera.sensor_width = 17.3
bpy.context.camera.sensor_height = 13.0
bpy.context.camera.sensor_fit = 'HORIZONTAL'
