import bpy
bpy.context.camera.sensor_width = 25.34
bpy.context.camera.sensor_height = 14.25
bpy.context.camera.sensor_fit = 'HORIZONTAL'
