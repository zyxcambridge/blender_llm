import bpy
bpy.context.camera.sensor_width = 5.76
bpy.context.camera.sensor_height = 4.29
bpy.context.camera.sensor_fit = 'HORIZONTAL'
