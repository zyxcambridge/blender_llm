import bpy
bpy.context.camera.sensor_width = 23.6
bpy.context.camera.sensor_height = 15.6
bpy.context.camera.sensor_fit = 'HORIZONTAL'
