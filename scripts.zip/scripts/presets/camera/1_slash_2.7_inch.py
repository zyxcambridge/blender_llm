import bpy
bpy.context.camera.sensor_width = 5.37
bpy.context.camera.sensor_height = 4.04
bpy.context.camera.sensor_fit = 'HORIZONTAL'
