import bpy
bpy.context.camera.sensor_width = 10.26
bpy.context.camera.sensor_height = 7.49
bpy.context.camera.sensor_fit = 'HORIZONTAL'
