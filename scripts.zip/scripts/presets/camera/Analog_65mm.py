import bpy
bpy.context.camera.sensor_width = 52.45
bpy.context.camera.sensor_height = 23.01
bpy.context.camera.sensor_fit = 'HORIZONTAL'
