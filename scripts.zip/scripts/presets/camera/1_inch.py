import bpy
bpy.context.camera.sensor_width = 13.2
bpy.context.camera.sensor_height = 8.80
bpy.context.camera.sensor_fit = 'HORIZONTAL'
