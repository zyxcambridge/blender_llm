import bpy
bpy.context.fluid.domain_settings.viscosity_base = 5.0
bpy.context.fluid.domain_settings.viscosity_exponent = 5
