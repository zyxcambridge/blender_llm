import bpy

filepaths = bpy.context.preferences.filepaths

filepaths.text_editor = ""
filepaths.text_editor_args = ""
