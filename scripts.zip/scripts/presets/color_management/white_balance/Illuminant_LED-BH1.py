import bpy
view_settings = bpy.context.scene.view_settings

view_settings.white_balance_temperature = 2852
view_settings.white_balance_tint = -0.9
