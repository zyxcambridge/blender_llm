import bpy
view_settings = bpy.context.scene.view_settings

view_settings.white_balance_temperature = 2856
view_settings.white_balance_tint = 0.0
