import bpy
view_settings = bpy.context.scene.view_settings

view_settings.white_balance_temperature = 5501
view_settings.white_balance_tint = 10.0
