import bpy
view_settings = bpy.context.scene.view_settings

view_settings.white_balance_temperature = 2997
view_settings.white_balance_tint = -2.8
