import bpy
view_settings = bpy.context.scene.view_settings

view_settings.white_balance_temperature = 4873
view_settings.white_balance_tint = -3.8
