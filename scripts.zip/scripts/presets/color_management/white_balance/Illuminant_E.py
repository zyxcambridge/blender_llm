import bpy
view_settings = bpy.context.scene.view_settings

view_settings.white_balance_temperature = 5454
view_settings.white_balance_tint = -13.0
