import bpy
view_settings = bpy.context.scene.view_settings

view_settings.white_balance_temperature = 2840
view_settings.white_balance_tint = 12.8
