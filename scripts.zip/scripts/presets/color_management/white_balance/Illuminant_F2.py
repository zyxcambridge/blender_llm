import bpy
view_settings = bpy.context.scene.view_settings

view_settings.white_balance_temperature = 4225
view_settings.white_balance_tint = 5.9
