import bpy
bpy.context.scene.render.fps = 50
bpy.context.scene.render.fps_base = 1
