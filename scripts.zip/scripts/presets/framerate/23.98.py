import bpy
bpy.context.scene.render.fps = 24
bpy.context.scene.render.fps_base = 1.001
