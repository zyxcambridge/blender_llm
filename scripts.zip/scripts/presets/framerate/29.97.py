import bpy
bpy.context.scene.render.fps = 30
bpy.context.scene.render.fps_base = 1.001
