import bpy
bpy.context.scene.render.fps = 25
bpy.context.scene.render.fps_base = 1
