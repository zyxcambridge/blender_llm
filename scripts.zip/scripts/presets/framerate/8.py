import bpy
bpy.context.scene.render.fps = 8
bpy.context.scene.render.fps_base = 1
