import bpy
bpy.context.scene.render.fps = 60
bpy.context.scene.render.fps_base = 1
