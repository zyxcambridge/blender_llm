import bpy
bpy.context.scene.render.fps = 6
bpy.context.scene.render.fps_base = 1
