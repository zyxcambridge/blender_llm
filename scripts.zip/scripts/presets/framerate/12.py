import bpy
bpy.context.scene.render.fps = 12
bpy.context.scene.render.fps_base = 1
