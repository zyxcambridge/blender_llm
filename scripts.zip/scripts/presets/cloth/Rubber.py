import bpy
bpy.context.cloth.settings.quality = 7
bpy.context.cloth.settings.mass = 3
bpy.context.cloth.settings.tension_stiffness = 15
bpy.context.cloth.settings.compression_stiffness = 15
bpy.context.cloth.settings.shear_stiffness = 15
bpy.context.cloth.settings.bending_stiffness = 25
bpy.context.cloth.settings.tension_damping = 25
bpy.context.cloth.settings.compression_damping = 25
bpy.context.cloth.settings.shear_damping = 25
bpy.context.cloth.settings.air_damping = 1
