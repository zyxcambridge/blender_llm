import bpy
bpy.context.cloth.settings.quality = 12
bpy.context.cloth.settings.mass = 1
bpy.context.cloth.settings.tension_stiffness = 40
bpy.context.cloth.settings.compression_stiffness = 40
bpy.context.cloth.settings.shear_stiffness = 40
bpy.context.cloth.settings.bending_stiffness = 10
bpy.context.cloth.settings.tension_damping = 25
bpy.context.cloth.settings.compression_damping = 25
bpy.context.cloth.settings.shear_damping = 25
bpy.context.cloth.settings.air_damping = 1
