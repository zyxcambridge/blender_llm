import bpy
bpy.context.cloth.settings.quality = 5
bpy.context.cloth.settings.mass = 0.300
bpy.context.cloth.settings.tension_stiffness = 15
bpy.context.cloth.settings.compression_stiffness = 15
bpy.context.cloth.settings.shear_stiffness = 15
bpy.context.cloth.settings.bending_stiffness = 0.500
bpy.context.cloth.settings.tension_damping = 5
bpy.context.cloth.settings.compression_damping = 5
bpy.context.cloth.settings.shear_damping = 5
bpy.context.cloth.settings.air_damping = 1.000
