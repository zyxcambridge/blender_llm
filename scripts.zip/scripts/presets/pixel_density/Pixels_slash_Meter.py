import bpy
bpy.context.scene.render.ppm_base = 1.0
