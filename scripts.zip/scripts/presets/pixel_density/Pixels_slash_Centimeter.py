import bpy
bpy.context.scene.render.ppm_base = 0.01
