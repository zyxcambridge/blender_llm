# Running Tests

```
./utils/paths_test.py
```
