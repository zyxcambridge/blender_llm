import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty, CollectionProperty, PointerProperty
from bpy.types import PropertyGroup

class AIMessageItem(PropertyGroup):
    text: StringProperty(name="Message", description="Message text", default="")
    is_user: BoolProperty(name="Is User", description="Whether this message is from the user", default=False)

class AIAssistantProperties(PropertyGroup):
    mode: EnumProperty(
        name="Mode",
        description="AI Assistant mode",
        items=[('AGENT', "Agent", "Agent mode"), ('CHAT', "Chat", "Chat mode")],
        default='AGENT',
    )
    message: StringProperty(name="Message", description="Message to send to the AI assistant", default="")
    messages: CollectionProperty(type=AIMessageItem, name="Messages", description="Chat history")
    active_message_index: IntProperty(name="Active Message Index", description="Index of the active message", default=0)
    keep_open: BoolProperty(name="Keep Open", description="Keep the AI Assistant panel open", default=False)

def register():
    try:
        bpy.utils.unregister_class(AIMessageItem)
    except Exception:
        pass
    try:
        bpy.utils.unregister_class(AIAssistantProperties)
    except Exception:
        pass
    bpy.utils.register_class(AIMessageItem)
    bpy.utils.register_class(AIAssistantProperties)
    bpy.types.Scene.ai_assistant = PointerProperty(type=AIAssistantProperties)

def unregister():
    if hasattr(bpy.types.Scene, "ai_assistant"):
        del bpy.types.Scene.ai_assistant
    try:
        bpy.utils.unregister_class(AIAssistantProperties)
    except Exception:
        pass
    try:
        bpy.utils.unregister_class(AIMessageItem)
    except Exception:
        pass

if __name__ == "__main__":
    register()
