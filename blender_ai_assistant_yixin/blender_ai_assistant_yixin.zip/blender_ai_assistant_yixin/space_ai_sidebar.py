import sys
import os
import json
import traceback
import bpy
import ai_gemini_integration

# 导入修复脚本模块
try:
    import fix_gemini_script

    has_fix_script = True
except ImportError:
    has_fix_script = False
    print("警告: 无法导入fix_gemini_script模块，修复脚本功能将不可用", flush=True)

from bpy.types import (
    Panel,
    PropertyGroup,
)
from bpy.props import (
    StringProperty,
    CollectionProperty,
    IntProperty,
    BoolProperty,
    PointerProperty,
)


def load_config():
    """从JSON配置文件加载设置"""
    config_path = ""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(script_dir, "ai_assistant_config.json")
    except NameError:
        print("无法确定脚本目录以查找 ai_assistant_config.json", flush=True)

    default_config = {
        "default_prompts": {
            "cartoon_character": "为一个名为「小兔子」的卡通角色创建完整3D模型...",
            "placeholder_short": "描述你想创建的模型...",
            "chat_mode": "Type a message or /subdivide, @",
        },
        "script_filename": "gemini_latest_code.py",
    }
    config = default_config.copy()

    if config_path and os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                loaded_config = json.load(f)
                for key, default_value in default_config.items():
                    if key in loaded_config:
                        if isinstance(default_value, dict) and isinstance(loaded_config[key], dict):
                            config[key].update(loaded_config[key])
                        else:
                            config[key] = loaded_config[key]
            print(f"配置已加载: {config_path}", flush=True)
        except json.JSONDecodeError as e:
            print(f"加载配置文件JSON解析错误: {e}，路径: {config_path}，使用默认配置。", flush=True)
        except Exception as e:
            print(f"加载配置文件时发生未知错误: {e}，路径: {config_path}，使用默认配置。", flush=True)
    else:
        if config_path:
            print(f"配置文件不存在: {config_path}，使用默认配置。", flush=True)
        else:
            print("未找到配置文件路径，使用默认配置。", flush=True)

    return config


CONFIG = load_config()
SCRIPT_FILENAME = CONFIG.get("script_filename", "gemini_latest_code.py")


class AIMessageItem(PropertyGroup):
    text: StringProperty(default="")
    is_user: BoolProperty(default=True)


class AIAssistantProperties(PropertyGroup):
    message: StringProperty(
        name="输入文本",
        description="输入提示或命令",
        default="",
        maxlen=4096,  # 增加最大长度限制
    )
    messages: CollectionProperty(type=AIMessageItem)
    active_message_index: IntProperty(default=-1)
    keep_open: BoolProperty(default=True)
    use_pin: BoolProperty(default=True)
    mode: StringProperty(default="AGENT")


class VIEW3D_PT_ai_assistant(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Blender AI Agent"
    bl_label = "Blender AI Agent"
    bl_options = {'HIDE_HEADER', 'DEFAULT_CLOSED'}
    bl_order = 0  # 确保面板显示在最上面

    @classmethod
    def poll(cls, context):
        return hasattr(context.scene, "ai_assistant")

    def draw_header(self, context):
        if hasattr(context.scene, "ai_assistant"):
            ai_props = context.scene.ai_assistant
            layout = self.layout
            # Make sure the property exists before trying to access it
            if hasattr(ai_props, "use_pin"):
                layout.prop(
                    ai_props, "use_pin", text="", icon='PINNED' if ai_props.use_pin else 'UNPINNED', emboss=False
                )
            else:
                print("Warning: 'use_pin' property not found in AIAssistantProperties", flush=True)

    def draw(self, context):
        layout = self.layout
        if not hasattr(context.scene, "ai_assistant"):
            layout.label(text="Blender AI助手尚未初始化。")
            row = layout.row()
            row.operator("ai.initialize", text="初始化 Blender AI助手", icon='FILE_REFRESH')
            return

        ai_props = context.scene.ai_assistant

        # 1. 标题区
        title_box = layout.box()
        title_row = title_box.row()
        title_row.label(text="Blender AI Agent", icon='OUTLINER_OB_ARMATURE')

        # 如果在调试模式下，显示重新初始化按钮
        if bpy.app.debug:
            debug_row = layout.row(align=True)
            debug_row.operator("ai.initialize", text="重新初始化", icon='FILE_REFRESH')

        # 2. 用户需求记录区
        history_box = layout.box()
        history_header = history_box.row(align=True)
        history_header.label(text="操作记录/信息输出区", icon='INFO')
        history_header.operator("ai.clear_history", text="", icon='TRASH', emboss=False)

        if len(ai_props.messages) > 0:
            history_content_box = history_box.box()
            max_history_display = 10
            start_idx = max(0, len(ai_props.messages) - max_history_display)
            for i in range(start_idx, len(ai_props.messages)):
                msg = ai_props.messages[i]
                row = history_content_box.row()
                prefix = "[用户] " if msg.is_user else "[AI] "
                icon = 'USER' if msg.is_user else ('ERROR' if '❌' in msg.text else 'LIGHT')
                display_text = msg.text.splitlines()[0]
                if len(display_text) > 80:
                    display_text = display_text[:77] + "..."
                row.label(text=prefix + display_text, icon=icon)
        else:
            history_box.label(text="暂无消息。")

        # 3. 用户需求输入文本区 - 大型输入框
        input_box = layout.box()
        input_box.label(text="输入提示:", icon='CONSOLE')

        # 使用column而不是row，以便于垂直扩展
        input_col = input_box.column()

        # 设置占位符文本
        placeholder = CONFIG.get("default_prompts", {}).get("placeholder_short", "描述你想创建的模型...")

        # 创建一个更高更宽的输入框
        # 使用column而不是row，确保输入框占据整个宽度
        big_input_col = input_col.column()
        big_input_col.scale_y = 6.0  # 显著增加输入框高度
        # 不需要设置scale_x，因为column会自动占据整个宽度
        big_input_col.prop(ai_props, "message", text="", placeholder=placeholder)

        # 4. 按钮区 - Agent 工作流程
        button_row = layout.row(align=True)
        button_row.scale_y = 1.5  # 增大按钮高度
        button_row.operator("ai.send_message", text="Agent 建模规划", icon='OUTLINER_OB_LIGHT')

        # 修复脚本错误按钮
        if has_fix_script:
            fix_row = layout.row(align=True)
            fix_row.scale_y = 1.5  # 增大按钮高度
            fix_row.operator("script.fix_gemini_code", text="Agent 评估反思", icon='OUTLINER_OB_FORCE_FIELD')

        # 执行 Blender Python 脚本按钮
        execute_row = layout.row(align=True)
        execute_row.scale_y = 1.5  # 增大按钮高度
        execute_row.operator("ai.execute_script", text="Agent 执行", icon='OUTLINER_OB_ARMATURE')
