bl_info = {
    "name": "Blender AI Assistant Yixin",
    "author": "Yixin",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Blender AI Agent",
    "description": "AI Copilot, Gemini Integration, 3D Modeling Assistant, and more.",
    "warning": "",
    "doc_url": "",
    "category": "3D View",
}

import bpy
from . import ai_gemini_integration
from . import fix_gemini_script
from . import gemini_code_evaluator
from . import ai_assistant_config
from .bl_ui import space_ai_sidebar, topbar_ai_menu, space_3d_moder

modules = [
    ai_gemini_integration,
    fix_gemini_script,
    gemini_code_evaluator,
    ai_assistant_config,
    space_ai_sidebar,
    topbar_ai_menu,
    space_3d_moder,
]

def register():
    for m in modules:
        if hasattr(m, "register"):
            try:
                m.register()
            except Exception as e:
                print(f"[Blender AI Assistant] Failed to register {m.__name__}: {e}")

def unregister():
    for m in reversed(modules):
        if hasattr(m, "unregister"):
            try:
                m.unregister()
            except Exception as e:
                print(f"[Blender AI Assistant] Failed to unregister {m.__name__}: {e}")

if __name__ == "__main__":
    register()

